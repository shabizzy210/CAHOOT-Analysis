library(ggplot2)
library(dplyr)
library(reshape2)
library(MASS) 
library(reshape) 
library(lubridate)
library(rddtools)
#Faster reading of csv due to its large amount, can just use stand read_csv instead
library(data.table)
options(max.print = 2000000) 

#Shift of project, now focus on the implementation of the MCSLC and its affects on CAHOOTS
#Focus on the January 2024 - March 2024 Time Frame, MCSCLC comes in November 2024
#Is there a drop in service


NEWDATA <- fread('NewData/newdata14-25.csv')

#Add date of events into months time series, now in YYYY-MM-01 format
NEWDATA$calltime <- as.POSIXct(NEWDATA$calltime, format = "%Y-%m-%d %H:%M:%OS")
NEWDATA$Month <- format(NEWDATA$calltime, format = "%Y-%m")

#Some calls are made to dispatch and no follow up is take, we will first filter out
#all the closed as calls that are not completed such as disregrad, no actiontaken
closed_as_pattern <- "DISREGARD|GONE ON ARRIVAL|QUALITY OF LIFE - NO DISPATCH|NO ACTION TAKEN|
QUIET ON ARRIVAL|DISREGARDED BY PATROL SUPERVISOR|CANCELED REPORT NUMBER|DUPLICATE EVENT|
CANCEL WHILE ENROUTE|DISREGARDED BY DISPATCH|UNABLE TO DISPATCH|ACCIDENTALLY CHOSE NEW EVENT|
FALSE ALARM|UNABLE TO LOCATE|UNFOUNDED"

#Removal of these types of call from the data
NEWDATA <- NEWDATA[!grepl(closed_as_pattern, NEWDATA$closed_as),]



#These are the known call signs for CAHOOTS in dispatch, we will use this to filter out the data for 
CALLSIGN <- "1J77\\s*|3J79\\s*|3J78\\s*|3J77\\s*|4J79\\s*|3J81\\s*|3J76\\s*|2J28\\s*|2J29\\s*|CAHOOT\\s*|CAHOT\\s*|CAHO\\s*"


#All CAHOOT Call logs
CAHOOTS <- NEWDATA[grep(CALLSIGN, NEWDATA$primeunit),]
#All Non-CAHOOT LOGS
NONCAHOOTS <- NEWDATA[!grepl(CALLSIGN, NEWDATA$primeunit),]


#Add times (Military Time Format) to CAHOOTS and Non_CAHOOTS data frames then
#We filter out the calls between 14:00 (2PM) to 23:00 (11PM) the operational 
#hours of MSCLC

CAHOOTS$TIME <- format(CAHOOTS$calltime, "%H:%M:%S")
NONCAHOOTS$TIME <-format(NONCAHOOTS$calltime, "%H:%M:%S")

emtpattern <-"SUBJECT DOWN|OVERDOSE|ANIMAL ATTACK/BITE|INJURED SUBJECT|MOTOR VEH ACC INJURY|HIT AND RUN INJURY|
RESPIRATORY ARREST|DROWNING|ASSAULT|FIGHT|CARDIAC ARREST|INDECENT EXPOSURE|SEX ABUSE|DOG BITE|MENTAL SUBJECT|
STAB WOUND|SODOMY|TRAIN VS PED/BIKE CRASH|CHEST PAIN|ACCIDENT ATV INJURY|INTOXICATED SUBJECT|RAPE|
ASSAULT WITH INJURY|SUICIDAL SUBJECT|MOTOR VEH ACC UNKNOWN INJ|TRANSPORT|POISONING|MENTAL TRANSPORT|
DISORIENTED SUBJECT|GUNSHOT WOUND|ILL SUBJECT|ACCIDENT AIRCRAFT INJURY|OVERDO"

#Filter CAHOOT Calls to only EMT type of nature now
EMTNONCAHOOTS <- NONCAHOOTS[grep(emtpattern, NONCAHOOTS$nature),]

#Total EMT-Type  calls
Police_EMTMonth_Calls <- as.data.frame(table(EMTNONCAHOOTS$Month))
colnames(Police_EMTMonth_Calls) <- c("Month", "Total")

# Remove April 2025 as it does not have a full month of data
Police_EMTMonth_Calls <- Police_EMTMonth_Calls[-nrow(Police_EMTMonth_Calls), ]

# Month of April 2020 is the first full month of COVID, so we set this as the cut off date
cutoff_date <- as.Date("2020-04-01")
# Chang the month into a index, allows for easier filtering of months
cutoff_index <- as.numeric(difftime(cutoff_date, as.Date("2014-01-01"), units = "days")) / 30.44


# Update month to correct month type and then date, then add the index of each month into the data frame
# we can filter out for specific months and time frames much easier this way
Police_EMTMonth_Calls$Month <- ym(Police_EMTMonth_Calls$Month)
Police_EMTMonth_Calls$Month <- as.Date(Police_EMTMonth_Calls$Month)
Police_EMTMonth_Calls$MonthIndex <- as.numeric(difftime(Police_EMTMonth_Calls$Month, as.Date("2014-01-01"), units = "days")) / 30.44

#For graphing this allows us to have to different scatter plots and slopes to show the two
#different groups
Police_EMTMonth_Calls$D <- ifelse(Police_EMTMonth_Calls$Month >= cutoff_date, 1, 0)

#Load in the data for RDD analysis
EMTRCHdata <- rdd_data(y = Police_EMTMonth_Calls$Total, 
                       x = Police_EMTMonth_Calls$MonthIndex, cutpoint = cutoff_index)

#Creation of RDD Model using data we just created
EMTRDD1 <- rdd_reg_lm(EMTRCHdata)

#Summary of results for RDD analysis
summary(EMTRDD1)


# Plotiing showing off the trend for Eugene police responding to EMT type calls before and after covid
# notice there is a noticeble difference in the trends. RDD analysis also confirms that the new slope
# after covid is significantly different.


police_emtcalls_graph <- ggplot(Police_EMTMonth_Calls, aes(x = Month, y = Total)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept =as.Date("2020-04-01"), linetype = "dashed", color = "black") +
  annotate("text",
           x = as.Date("2020-04-01"),
           y = max(Police_EMTMonth_Calls$Total, na.rm = TRUE) * 0.95,
           label = "COVID",
           angle = 0, vjust = 20, hjust=1.1,size = 4.5) +
  annotate("text",
           x = as.Date("2020-04-01"),
           y = max(Police_EMTMonth_Calls$Total, na.rm = TRUE) * 0.95,
           label = "April 2024",
           angle = 0, vjust = 22, hjust=1.1,size = 4.5) +
  geom_smooth(data = subset(Police_EMTMonth_Calls, D == 0), method = "lm", se = FALSE, size=2.5, color = "red") +
  geom_smooth(data = subset(Police_EMTMonth_Calls, D == 1), method = "lm", se = FALSE, size=2.5, color = "orange") +
  labs(title = "Police EMT Analysis",
       x = "Years",
       y = "Total Calls") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))

police_emtcalls_graph




