library(ggplot2)
library(dplyr)
library(reshape2)
library(MASS) 
library(reshape) 
library(lubridate)
library(rddtools)
library(data.table)
options(max.print = 2000000) 

#Shift of project, now focus on the implementation of the MCSLC and its affects on CAHOOTS
#Focus on the January 2024 - March 2024 Time Frame, MCSCLC comes in November 2024
#Is there a drop in service


NEWDATA <- fread('NewData/newdata14-25.csv')

#Add date of events into months time series, now in YYYY-MM-01 format
NEWDATA$calltime <- as.POSIXct(NEWDATA$calltime, format = "%Y-%m-%d %H:%M:%OS")
NEWDATA$Month <- format(NEWDATA$calltime, format = "%Y-%m")

#Some calls are made to dispatch and no follow up is take, we will first filter out
#all the closed as calls that are not completed such as disregrad, no actiontaken
closed_as_pattern <- "DISREGARD|GONE ON ARRIVAL|QUALITY OF LIFE - NO DISPATCH|NO ACTION TAKEN|
QUIET ON ARRIVAL|DISREGARDED BY PATROL SUPERVISOR|CANCELED REPORT NUMBER|DUPLICATE EVENT|
CANCEL WHILE ENROUTE|DISREGARDED BY DISPATCH|UNABLE TO DISPATCH|ACCIDENTALLY CHOSE NEW EVENT|
FALSE ALARM|UNABLE TO LOCATE|UNFOUNDED"

#Removal of these types of call from the data
NEWDATA <- NEWDATA[!grepl(closed_as_pattern, NEWDATA$closed_as),]



#These are the known call signs for CAHOOTS in dispatch, we will use this to filter out the data for 
CALLSIGN <- "1J77\\s*|3J79\\s*|3J78\\s*|3J77\\s*|4J79\\s*|3J81\\s*|3J76\\s*|2J28\\s*|2J29\\s*|CAHOOT\\s*|CAHOT\\s*|CAHO\\s*"


#All CAHOOT Call logs
CAHOOTS <- NEWDATA[grep(CALLSIGN, NEWDATA$primeunit),]
#All Non-CAHOOT LOGS
NONCAHOOTS <- NEWDATA[!grepl(CALLSIGN, NEWDATA$primeunit),]


#Add times (Military Time Format) to CAHOOTS and Non_CAHOOTS data frames then
#We filter out the calls between 14:00 (2PM) to 23:00 (11PM) the operational 
#hours of MSCLC

CAHOOTS$TIME <- format(CAHOOTS$calltime, "%H:%M:%S")
NONCAHOOTS$TIME <-format(NONCAHOOTS$calltime, "%H:%M:%S")
CAHOOTS211 <-  CAHOOTS %>% filter(TIME >= 14 & TIME <= 23)
NONCHTS211 <-  NONCAHOOTS %>% filter(TIME >= 14 & TIME <= 23)

#Renaming of columns, to more clear column names used temp dataframe as this will
# move to actual data frame main data frame
TEMPNCH <- as.data.frame(table(NONCHTS211$Month))
colnames(TEMPNCH) <- c("Month", "Total")

CH211_total_calls <- as.data.frame(table(CAHOOTS211$Month))
colnames(CH211_total_calls) <- c("Month", "Total")

CH211_total_calls <- CH211_total_calls %>%
  left_join(TEMPNCH, select(Month, Total), by = c("Month"))
colnames(CH211_total_calls) <- c("Month", "TotalCahoots", "TotalNonCAHOOTS")

#Removal of April 2025, as it is a incomplete month 
CH211_total_calls <- CH211_total_calls %>% filter(row_number() <= n()-1)

#Change of Month to allow for plotting in line graph
CH211_total_calls$Month <- ym(CH211_total_calls$Month)

# Need to see if there is any actual drop in coverage for the data, I will be 
# attempting to use a Regression Discontinuity Design. First the dates will changed into a index
# to place cut off point for our data. I am setting September 2024 as the cut off date as this
# when MSCLC started they operations, and we will have our answer if there was any decrease of
# CAHOOTs calls after its implementation
CH211_total_calls$Month <- as.Date(CH211_total_calls$Month)
CH211_total_calls$MonthIndex <- as.numeric(difftime(CH211_total_calls$Month, as.Date("2014-01-01"), units = "days")) / 30.44


cutoff_date <- as.Date("2024-08-01")
cutoff_index <- as.numeric(difftime(cutoff_date, as.Date("2014-01-01"), units = "days")) / 30.44

#If the month is after September 2024 it has a value of 1 now
CH211_total_calls$D <- ifelse(CH211_total_calls$Month >= cutoff_date, 1, 0)

#RDD for the CAHOOTS total calls
RDDCH <- rdd_data(y = CH211_total_calls$TotalCahoots, 
                  x = CH211_total_calls$MonthIndex, cutpoint = cutoff_index)

rdd_totcahoots <- rdd_reg_lm(RDDCH)


#Running of both RDD models
summary(rdd_totcahoots)



#Plotting of both models showing distrbution of calls and the cut off date of september
ggplot(CH211_total_calls, aes(x = Month, y = TotalCahoots)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2024-08-01"), linetype = "dashed", color = "black") +
  geom_smooth(data = subset(CH211_total_calls, D == 0), method = "lm", se = FALSE, color = "red", linewidth=1.5) +
  geom_smooth(data = subset(CH211_total_calls, D == 1), method = "lm", se = FALSE, color = "orange", linewidth=1.5) +
  labs(title = "CAHOOT MSCLC Analsyis",
       x = "Year",
       y = "CAHOOTS Calls Per Month 2-11PM") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))



CH211OVER80 <- subset(CH211_total_calls, MonthIndex >=80)

RDD2 <- rdd_data(y = CH211OVER80$TotalCahoots, 
                  x = CH211OVER80$MonthIndex, cutpoint = cutoff_index)

mrdd2 <- rdd_reg_lm(RDD2)

#CH211OVER80$Month <- as.Date(CH211OVER80$Month)

summary(mrdd2)

ggplot(CH211OVER80, aes(x = Month, y = TotalCahoots)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2024-08-01"), linetype = "dashed", color = "black") +
  annotate("text",
           x = as.Date("2024-08-01"),
           y = max(CH211OVER80$TotalCahoots, na.rm = TRUE) * 0.95,
           label = "MCSLC Operational",
           angle = 0, vjust = 18, hjust=1.1, size = 4.5) +
            coord_cartesian(ylim = c(300, NA)) +
            annotate("text",
           x = as.Date("2024-08-01"),
           y = max(CH211OVER80$TotalCahoots, na.rm = TRUE) * 0.95,
           label = "August 2024",
           angle = 0, vjust = 20, hjust=1.1, size = 4.5) +
  geom_smooth(data = subset(CH211OVER80, D == 0), method = "lm", se = FALSE, color = "red", linewidth=2.5) +
  geom_smooth(data = subset(CH211OVER80, D == 1), method = "lm", se = FALSE, color = "orange", linewidth=2.5) +
  labs(title = "CAHOOT MCSLC Impact Analsyis",
       x = "Year",
       y = "Total Calls") +
  theme_bw() +  # white background with borders
  theme(
    plot.title = element_text(hjust = 0.5),
    panel.border = element_rect(colour = "black", fill = NA),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank()
  ) +
  theme(plot.title = element_text(hjust = 0.5))



