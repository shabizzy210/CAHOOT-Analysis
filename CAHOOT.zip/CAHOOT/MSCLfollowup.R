library(ggplot2)
library(dplyr)
library(reshape2)
library(MASS) 
library(reshape) 
library(lubridate)
library(rddtools)
#Faster reading of csv due to its large amount, can just use standard read_csv instead
library(data.table)

options(max.print = 2000000) 

#Shift of project, now focus on the implementation of the MCSLC and its affects on CAHOOTS
#Focus on the January 2024 - March 2024 Time Frame, MCSCLC comes in November 2024
#Is there a drop in service


NEWDATA <- fread('NewData/newdata14-25.csv')

#Add date of events into months time series, now in YYYY-MM-01 format
NEWDATA$calltime <- as.POSIXct(NEWDATA$calltime, format = "%Y-%m-%d %H:%M:%OS")
NEWDATA$Month <- format(NEWDATA$calltime, format = "%Y-%m")

#Some calls are made to dispatch and no follow up is take, we will first filter out
#all the closed as calls that are not completed such as disregrad, no actiontaken
closed_as_pattern <- "DISREGARD|GONE ON ARRIVAL|QUALITY OF LIFE - NO DISPATCH|NO ACTION TAKEN|
QUIET ON ARRIVAL|DISREGARDED BY PATROL SUPERVISOR|CANCELED REPORT NUMBER|DUPLICATE EVENT|
CANCEL WHILE ENROUTE|DISREGARDED BY DISPATCH|UNABLE TO DISPATCH|ACCIDENTALLY CHOSE NEW EVENT|
FALSE ALARM|UNABLE TO LOCATE|UNFOUNDED"

#Removal of these types of call from the data
NEWDATA <- NEWDATA[!grepl(closed_as_pattern, NEWDATA$closed_as),]



#These are the known call signs for CAHOOTS in dispatch, we will use this to filter out the data for 
CALLSIGN <- "1J77\\s*|3J79\\s*|3J78\\s*|3J77\\s*|4J79\\s*|3J81\\s*|3J76\\s*|2J28\\s*|2J29\\s*|CAHOOT\\s*|CAHOT\\s*|CAHO\\s*"


#All CAHOOT Call logs
CAHOOTS <- NEWDATA[grep(CALLSIGN, NEWDATA$primeunit),]
#All Non-CAHOOT LOGS
NONCAHOOTS <- NEWDATA[!grepl(CALLSIGN, NEWDATA$primeunit),]

#Following up on the MSCLC analysis, instead of all calls we will just focus on calls such as mental,
#transport, check welfare only. Those should be calls that MSCSLC and CAHOOTS share, if there is not
#a significant drop, then we can strongly say that MCSLC did not signifcantly affect CAHOOTS.

#This pattern is all the mental, transport type calls CAHOOTs handles
#transport_and_mentalpattern <- "TRANSPORT|CHECK WELFARE|CHECK WELFARE, CAHOOTS|MENTAL TRANSPORT|
#TRANSPORT, CAHOOT|MENTAL SUBJECT|SUICIDAL SUBJECT, CAHOOTS"

transport_and_mentalpattern <- "CHECK WELFARE|CHECK WELFARE, CAHOOTS|MENTAL TRANSPORT|
MENTAL SUBJECT|SUICIDAL SUBJECT, CAHOOTS"

#Filter only for these type of calls only
CHMENTAL <- CAHOOTS[grep(transport_and_mentalpattern,CAHOOTS$nature),]

#add time of calls
CHMENTAL$TIME <- format(CHMENTAL$calltime, "%H:%M:%S")

#subset CHMENTAL for only calls that take place between 2pm and 11pm, this is when MSCLC
# mobile vans are active according to their website
CHMENTAL211 <-  CHMENTAL %>% filter(TIME >= 14 & TIME <= 23)

#The next set of codes allow us to create a table that counts the total amount of calls per month
# and then change the month into a actual date, this will be important for the RDD analysis
Mental_totals211 <- as.data.frame(table(CHMENTAL211$Month))
Mental_totals211 <- Mental_totals211 %>% filter(row_number() <= n()-1)
colnames(Mental_totals211) <- c("Month", "Total")
Mental_totals211$Month <- ym(Mental_totals211$Month) 
Mental_totals211$Month <- as.Date(Mental_totals211$Month) 

# We add a month index, all this does it allows a more simpler way of separating data instead of using
# the month, also for plotting this will be very important. This divides the month by how many days 
# have passed since January 2014
Mental_totals211$MonthIndex <- as.numeric(difftime(Mental_totals211$Month, as.Date("2014-01-01"), units = "days")) / 30.44
cutoff_date <- as.Date("2024-08-01")
cutoff_index <- as.numeric(difftime(cutoff_date, as.Date("2014-01-01"), units = "days")) / 30.44

#If the month is after September 2024 it has a value of 1 now
Mental_totals211$D <- ifelse(Mental_totals211$Month >= cutoff_date, 1, 0)

#This is just plotting lookin only 2020-2025. CAHOOTS calls stabilize around this time
#compared to 2014-2019 where it was more volatile, with this we hope a more consistent
#total calls may impact the RDD Analsysi
Mental_totals211V2 <- subset(Mental_totals211, MonthIndex > 74)


#load the RDD data
rdd_mental <- rdd_data(y = Mental_totals211$Total, 
                  x = Mental_totals211$MonthIndex, cutpoint = cutoff_index)
rdd_totcahoots <- rdd_reg_lm(rdd_mental)

#with a P-value .99 and .958 for the alternative version we can confidently say that 
#CAHOOT calls were not affected by the arrival of MSCLC
summary(rdd_totcahoots)


#Plot showing the cut off point, and two slopes for before and after the cutoff date
ggplot(Mental_totals211, aes(x = Month, y = Total)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2024-08-01"), linetype = "dashed", color = "black", size=1.5) +
  geom_smooth(data = subset(Mental_totals211, D == 0), method = "lm", se = FALSE, color = "red", linewidth=2.5) +
  geom_smooth(data = subset(Mental_totals211, D == 1), method = "lm", se = FALSE, color = "orange", linewidth=2.5) +
  labs(title = "CAHOOT MSCLC Analsyis (Mental Calls Only",
       x = "Year",
       y = "Total Calls") +
  theme_bw() +  # white background with borders
  theme(
    plot.title = element_text(hjust = 0.5),
    panel.border = element_rect(colour = "black", fill = NA),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank()
  ) +
  theme(plot.title = element_text(hjust = 0.5))



#Table for total CAHOOT calls in comparison
total_calls <- as.data.frame(table(CAHOOTS$Month))
colnames(total_calls) <- c("Month", "Total")
#total_calls <- total_calls %>% filter(row_number() <= n()-1)
total_calls$Month <- ym(total_calls$Month)

# Scatter plot showing the total calls over the years for CAHOOTs
ggplot(total_calls, aes(x = Month, y = Total)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2024-08-01"), linetype = "dashed", color = "black")+
  labs(title = "CAHOOT Call Analsyis",
       x = "Year",
       y = "CAHOOTS Calls Per Month") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))


ggplot(Mental_totals211V2, aes(x = Month, y = Total)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2024-08-01"), linetype = "dashed", color = "black", size=1.5) +
  geom_smooth(data = subset(Mental_totals211V2, D == 0), method = "lm", se = FALSE, color = "red", linewidth=2.5) +
  geom_smooth(data = subset(Mental_totals211V2, D == 1), method = "lm", se = FALSE, color = "orange", linewidth=2.5) +
  labs(title = "CAHOOT MSCLC Analsyis (Mental Calls Only",
       x = "Year",
       y = "Total Calls") +
  theme_bw() +  # white background with borders
  theme(
    plot.title = element_text(hjust = 0.5),
    panel.border = element_rect(colour = "black", fill = NA),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank()
  ) +
  theme(plot.title = element_text(hjust = 0.5))
