library(ggplot2)
library(dplyr)
library(reshape2)
library(MASS) 
library(reshape) 
library(lubridate)
library(rddtools)
library(patchwork)
library(data.table)
options(max.print = 2000000) 

#Shift of project, now focus on the implementation of the MCSLC and its affects on CAHOOTS
#Focus on the January 2024 - March 2024 Time Frame, MCSCLC comes in November 2024
#Is there a drop in service


NEWDATA <- fread('NewData/newdata14-25.csv')

#Add date of events into months time series, now in YYYY-MM-01 format
NEWDATA$calltime <- as.POSIXct(NEWDATA$calltime, format = "%Y-%m-%d %H:%M:%OS")
NEWDATA$Month <- format(NEWDATA$calltime, format = "%Y-%m")

#Some calls are made to dispatch and no follow up is take, we will first filter out
#all the closed as calls that are not completed such as disregrad, no actiontaken
closed_as_pattern <- "DISREGARD|GONE ON ARRIVAL|QUALITY OF LIFE - NO DISPATCH|NO ACTION TAKEN|
QUIET ON ARRIVAL|DISREGARDED BY PATROL SUPERVISOR|CANCELED REPORT NUMBER|DUPLICATE EVENT|
CANCEL WHILE ENROUTE|DISREGARDED BY DISPATCH|UNABLE TO DISPATCH|ACCIDENTALLY CHOSE NEW EVENT|
FALSE ALARM|UNABLE TO LOCATE|UNFOUNDED"

#Removal of these types of call from the data
NEWDATA <- NEWDATA[!grepl(closed_as_pattern, NEWDATA$closed_as),]



#These are the known call signs for CAHOOTS in dispatch, we will use this to filter out the data for 
CALLSIGN <- "1J77\\s*|3J79\\s*|3J78\\s*|3J77\\s*|4J79\\s*|3J81\\s*|3J76\\s*|2J28\\s*|2J29\\s*|CAHOOT\\s*|CAHOT\\s*|CAHO\\s*"


#All CAHOOT Call logs
CAHOOTS <- NEWDATA[grep(CALLSIGN, NEWDATA$primeunit),]
#All Non-CAHOOT LOGS
NONCAHOOTS <- NEWDATA[!grepl(CALLSIGN, NEWDATA$primeunit),]


#Add times (Military Time Format) to CAHOOTS and Non_CAHOOTS data frames then
#We filter out the calls between 14:00 (2PM) to 23:00 (11PM) the operational 
#hours of MSCLC

CAHOOTS$TIME <- format(CAHOOTS$calltime, "%H:%M:%S")
NONCAHOOTS$TIME <-format(NONCAHOOTS$calltime, "%H:%M:%S")



# EMT related calls, no check welfare is included in this as that could vary and we don't have any
# follow up on what happened after the check welfare
emtpattern2 <-"SUICIDAL SUBJECT| INTOXICATED SUBJECT| MOTOR VEH ACC UNKNOWN INJ|ACCIDENT VEHICLE BIKE|
  DOG BITE|CARDIAC ARREST|INJURED SUBJECT|TRANSPORT| NUDE SUBJECT| OVERDOSE|GUNSHOT WOUND|POISONING|STAB WOUND|
  ASSAULT WITH INJURY|VEHICLE/PEDESTRIAN CRASH|SEX ABUSE|FIGHT| SUBJECT SCREAMING|SUBJECT DOWN|
  ASSAULT|INDECENT EXPOSURE|RAPE|SODOMY|SEIZURES|CHEST PAIN|OVERDOSE|INTOXICATED SUBJECT, CAHOOTS|
  TRANSPORT, CAHOOTS|DISORIENTED SUBJECT, CAHOOTS|ACCIDENT TRAIN INJURY|DROWNING|RESPIRATORY ARREST|DETOXIFICATION|
INJURED SUBJECT|MENTAL TRANSPORT|TRANSPORT|DISORIENTED SUBJECT|SODOMY|TRAIN VS PED/BIKE CRASH"

#Filter CAHOOT Calls to only EMT type of nature now
EMTCAHOOTS <- CAHOOTS[grep(emtpattern2, CAHOOTS$nature),]

#Total EMT Cahoot calls
EMTMonth_Calls <- as.data.frame(table(EMTCAHOOTS$Month))
colnames(EMTMonth_Calls) <- c("Month", "Total")

# Remove April 2025 as it does not have a full month of data
EMTMonth_Calls <- EMTMonth_Calls[-nrow(EMTMonth_Calls), ]

#Now focusing on RDD analysis for EMT type calls, we will look to see if COVID affected CAHOOTS
#Responding to EMT type of calls

EMTMonth_Calls$Month <- ym(EMTMonth_Calls$Month)
EMTMonth_Calls$Month <- as.Date(EMTMonth_Calls$Month)
EMTMonth_Calls$MonthIndex <- as.numeric(difftime(EMTMonth_Calls$Month, as.Date("2014-01-01"), units = "days")) / 30.44
cutoff_date <- as.Date("2020-04-01")
cutoff_index <- as.numeric(difftime(cutoff_date, as.Date("2014-01-01"), units = "days")) / 30.44

EMTMonth_Calls$D <- ifelse(EMTMonth_Calls$Month >= cutoff_date, 1, 0)

EMTRCHdata <- rdd_data(y = EMTMonth_Calls$Total, 
                       x = EMTMonth_Calls$MonthIndex, cutpoint = cutoff_index)

EMTRDD1 <- rdd_reg_lm(EMTRCHdata)

summary(EMTRDD1)

ggplot(EMTMonth_Calls, aes(x = Month, y = Total)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2020-04-01"), linetype = "dashed", color = "black") +
  geom_smooth(data = subset(EMTMonth_Calls, D == 0), method = "lm", se = FALSE, color = "red", linewidth=1.5) +
  geom_smooth(data = subset(EMTMonth_Calls, D == 1), method = "lm", se = FALSE, color = "orange", linewidth=1.5) +
  labs(title = "CAHOOT EMT Analsyis",
       x = "Year",
       y = "Total Calls Per") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))

CAHOOTEMT_graph <-ggplot(EMTMonth_Calls, aes(x = Month, y = Total)) +
  geom_point(alpha = 1.2, size=4) +
  geom_vline(xintercept = as.Date("2020-04-01"), linetype = "dashed", color = "black") +
  annotate("text",
         x = as.Date("2020-04-01"),
         y = max(EMTMonth_Calls$Total, na.rm = TRUE) * 0.95,
         label = "COVID",
         angle = 0, vjust = 20, hjust=1.1,size = 4.5) +
  annotate("text",
           x = as.Date("2020-04-01"),
           y = max(EMTMonth_Calls$Total, na.rm = TRUE) * 0.95,
           label = "April 2024",
           angle = 0, vjust = 22, hjust=1.1,size = 4.5) +
  geom_smooth(data = subset(EMTMonth_Calls, D == 0), method = "lm", se = FALSE, color = "red", linewidth=2.5) +
  geom_smooth(data = subset(EMTMonth_Calls, D == 1), method = "lm", se = FALSE, color = "orange", linewidth=2.5) +
  labs(title = "CAHOOT Medical Emergency Analsyis",
       x = "Year",
       y = "Total Calls") +
  theme_bw() +  # white background with borders
  theme(
    plot.title = element_text(hjust = 0.5),
    panel.border = element_rect(colour = "black", fill = NA),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank()
  ) +
  theme(plot.title = element_text(hjust = 0.5))

CAHOOTEMT_graph

#Build linear model for EMT amount of calls, to estimate how many people are affected. Loss of these
# services, focus only on April 2020 onward

APR2020_onward <- subset(EMTMonth_Calls, MonthIndex >= 74 )

EMTModel <- lm(Total ~ MonthIndex, data=APR2020_onward)

post_CAHOOTS <- data.frame(
  MonthIndex = seq(134, 139, by = 1) )

post_CAHOOTS$predicted_calls <- predict(EMTModel, newdata = post_CAHOOTS)

# Based on the model, an estimated 190 EMT calls each month will not be served by CAHOOTS


mean(EMTMonth_Calls$Total[EMTMonth_Calls$D == 0])
mean(EMTMonth_Calls$Total[EMTMonth_Calls$D == 1])

100/6
